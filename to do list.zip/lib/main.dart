import 'package:flutter/material.dart';

void main() {
  runApp(TodoApp());
}

class Todo {
  String task;
  bool completed;
  DateTime deadline;

  Todo({
    required this.task,
    required this.completed,
    required this.deadline,
  });
}

class TodoApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Todo List',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        backgroundColor: Colors.yellow, // Set background color to yellow
      ),
      home: LoginScreen(),
    );
  }
}

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            TextField(
              decoration: InputDecoration(
                labelText: 'Username',
              ),
            ),
            SizedBox(height: 16.0),
            TextField(
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Password',
              ),
            ),
            SizedBox(height: 32.0),
            ElevatedButton(
              onPressed: () {
                // Perform authentication
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => TodoList()),
                );
              },
              child: Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}

class TodoList extends StatefulWidget {
  @override
  _TodoListState createState() => _TodoListState();
}

class _TodoListState extends State<TodoList> {
  List<Todo> _tasks = [];

  TextEditingController _taskController = TextEditingController();
  TextEditingController _editTaskController = TextEditingController();

  DateTime _selectedDateTime = DateTime.now();

  void _addTask() {
    setState(() {
      String newTask = _taskController.text;
      if (newTask.isNotEmpty) {
        _tasks.add(Todo(
          task: newTask,
          completed: false,
          deadline: _selectedDateTime,
        ));
        _taskController.clear();
      }
    });
  }

  void _updateTask(int index, String updatedTask) {
    setState(() {
      _tasks[index].task = updatedTask;
    });
  }

  void _toggleTaskCompletion(int index) {
    setState(() {
      _tasks[index].completed = !_tasks[index].completed;
    });
  }

  void _deleteTask(int index) {
    setState(() {
      _tasks.removeAt(index);
    });
  }

  Future<void> _selectDateTime(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDateTime,
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (picked != null) {
      final TimeOfDay? timePicked = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.fromDateTime(_selectedDateTime),
      );
      if (timePicked != null) {
        setState(() {
          _selectedDateTime = DateTime(
            picked.year,
            picked.month,
            picked.day,
            timePicked.hour,
            timePicked.minute,
          );
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Todo List'),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ],
      ),
      backgroundColor: Colors.yellow, // Set background color to yellow
      body: Column(
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(10.0),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _taskController,
                    decoration: InputDecoration(
                      labelText: 'Add Task',
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.calendar_today),
                  onPressed: () => _selectDateTime(context),
                ),
                IconButton(
                  icon: Icon(Icons.add),
                  onPressed: _addTask,
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _tasks.length,
              itemBuilder: (BuildContext context, int index) {
                Todo todo = _tasks[index];
                return ListTile(
                  title: Text(
                    todo.task,
                    style: TextStyle(
                      color: todo.completed
                          ? Colors.green
                          : Colors
                              .red, // Change color based on completion status
                    ),
                  ),
                  subtitle: Text('Deadline: ${todo.deadline.toString()}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      IconButton(
                        icon: Icon(Icons.edit),
                        onPressed: () {
                          _editTaskModalBottomSheet(context, index);
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.check_circle_outline),
                        onPressed: () {
                          _toggleTaskCompletion(index);
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () {
                          _deleteTask(index);
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _editTaskModalBottomSheet(BuildContext context, int index) {
    String updatedTask = _tasks[index].task;
    _editTaskController.text = updatedTask;

    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Container(
          padding: EdgeInsets.all(10.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                controller: _editTaskController,
                decoration: InputDecoration(
                  labelText: 'Update Task',
                ),
              ),
              SizedBox(height: 10.0),
              ElevatedButton(
                child: Text('Update'),
                onPressed: () {
                  updatedTask = _editTaskController.text;
                  _updateTask(index, updatedTask);
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        );
      },
    );
  }
}
