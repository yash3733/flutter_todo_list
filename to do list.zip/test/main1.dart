import 'package:flutter/material.dart';

void main() {
  runApp(MyFitnessApp());
}

class MyFitnessApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Fitness App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AuthenticationPage(),
    );
  }
}

class AuthenticationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200], // Set background color here
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // Implement authentication logic
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => UserProfilePage()),
            );
          },
          child: Text('Login'),
        ),
      ),
    );
  }
}

class UserProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200], // Set background color here
      appBar: AppBar(
        title: Text('User Profile'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Welcome to My Fitness App!'),
            SizedBox(height: 20),
            Image.asset(
              'assets/images/user_profile_image.png',
              width: 150,
              height: 150,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Implement navigation to workout tracking page
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => WorkoutTrackingPage()),
                );
              },
              child: Text('Start Workout'),
            ),
          ],
        ),
      ),
    );
  }
}

class WorkoutTrackingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff0c0000), // Set background color here
      appBar: AppBar(
        title: Text('Workout Tracking'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Track your workouts here!'),
            SizedBox(height: 20),
            ExerciseWidget(
              title: 'Push-ups',
              image: '"C:\Users\TEMP.WDC.000\Desktop\pushups.jpg"',
            ),
            ExerciseWidget(
              title: 'Squats',
              image: '"C:\Users\TEMP.WDC.000\Desktop\squats.webp"',
            ),
            ExerciseWidget(
              title: 'Plank',
              image: '"C:\Users\TEMP.WDC.000\Desktop\plank.jpg"',
            ),
          ],
        ),
      ),
    );
  }
}

class ExerciseWidget extends StatelessWidget {
  final String title;
  final String image;

  ExerciseWidget({required this.title, required this.image});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10),
      child: Column(
        children: [
          Text(
            title,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10),
          Image.asset(
            image,
            width: 150,
            height: 150,
            fit: BoxFit.cover,
          ),
        ],
      ),
    );
  }
}
